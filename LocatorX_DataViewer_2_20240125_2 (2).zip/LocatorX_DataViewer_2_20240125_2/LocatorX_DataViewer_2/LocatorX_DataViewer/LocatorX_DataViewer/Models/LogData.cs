﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Controller_Tester.Standard_Simulation
{
    public class LogData
    {
        public string Log
        {
            get;
            set;
        }
        public int IsHighlighted
        {
            get;
            set;
        }

    }
}
