﻿namespace Controller_Tester.Standard_Simulation
{
    internal class DispatcherTime
    {
    }
}